type MenuItemImage = {
  id: string;
  menuItemId: string;
  url: string;
  publicId: string;
  order: number;
  createdAt: string;
};

export type MenuItem = {
  id: string;
  name: string;
  description: string;
  price: number;
  category: string;
  isAvailable: boolean;
  createdAt: string;
  updatedAt: string;
  images: MenuItemImage[];
};

type PaginationMeta = {
  total: number;
  page: number;
  limit: number;
  totalPages: number;
};

type MenuResponse = {
  data: MenuItem[];
  meta: PaginationMeta;
};

export type MenuQeury = {
  data: MenuResponse | undefined;
  isError: boolean;
  isPending: boolean;
  error: any;
};

type Category = {
  id: string;
  name: string;
  slug: string;
  description: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
};

type Categories = Category[];

export type ButtonCategoryProps = {
  label: string;
  isActive: boolean;
};

export type CardProductProps = {
  index: number;
  name: string;
  description: string;
  price: number;
  isAvailable: boolean;
  images: MenuItemImage[];
};

export type CategoryFilterProps = {
  setCategory: any;
  category: string;
};

