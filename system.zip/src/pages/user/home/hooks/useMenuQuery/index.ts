
import { useQuery } from "@tanstack/react-query";
import { fetchMenu } from "@/pages/user/home/api";
import type { ResponseData } from "@/utils/types";

export const useFetchMenu = (page: number, limit: number, category: string) => {
  return useQuery<ResponseData>({
    queryKey: ["menu", category, page],
    queryFn: () => fetchMenu(page, limit, category),
    refetchOnWindowFocus: false,
  });
};
