import type { Categories } from "@/pages/user/home/models";
import { useQuery } from "@tanstack/react-query";
import { fetchCategories } from "@/pages/user/home/api";

export const useFetchCategories = () => {
  return useQuery<Categories>({
    queryKey: ["categories"],
    queryFn: fetchCategories,
    refetchOnWindowFocus: false,
  });
};