type Image = {
  url: string;
  id: string;
};

type MenuItems = {
  name: string;
  images: Image[];
};

type Addons = {
  price: number;
  name: string;
};

export type CardResponse = {
  quantity: number;
  totalPrice: number;
  menuItem: MenuItems;
  addons: Addons[];
  id: string;
  unitPrice: number;
};

export type CardProductProps = {
  image: string;
  title: string;
  addons?: Addons[];
  unitPrice: number;
  totalPrice: number;
  quantity: number;
  id: string;
  setTotalPriceItems: (value: number | ((prev: number) => number)) => void;
};
