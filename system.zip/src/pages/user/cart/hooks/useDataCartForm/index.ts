import { useState } from "react";
import { toast } from "react-toastify";
import useDeleteItemQuery from "../useDeleteItemQuery";
import useUpdateCartQeury from "../useUpdateCartQeury";
import { useQueryClient } from "@tanstack/react-query";
import { useCartStore } from "@/store/cart";

export default function useDataCartForm({
  quantity,
  id,
  totalPrice,
  title,
  unitPrice,
  setTotalPriceItems,
}: {
  quantity: number;
  id: string;
  totalPrice: number;
  title: string;
  unitPrice: number;
  setTotalPriceItems: (value: number | ((prev: number) => number)) => void;
}) {
    const {dec} = useCartStore()
  const [count, setCount] = useState(quantity);
  const [total_Price, set_total_Price] = useState(totalPrice);
  const [openPopup, setOpenPopup] = useState(false);

  const { mutate, isPending } = useDeleteItemQuery(id);
  const { mutate: updateCart, isPending: isLoadingCart } = useUpdateCartQeury(
    id,
    count,
  );

  const queryClient = useQueryClient();
  function handleDeleteItem() {

    setTotalPriceItems((price) => price - total_Price);
    mutate(undefined, {
      onSuccess: () => {
        toast.success(`تم حذف ${title} بنجاح`);
        queryClient.invalidateQueries({
          queryKey: ["cart"],
        });
        dec()
        setOpenPopup(false);
      },
      onError: (error) => {
        console.log(error);
      },
    });
  }

  function updateItem() {
    updateCart(undefined, {
      onSuccess: () => {
        queryClient.invalidateQueries({
          queryKey: ["cart"],
        });
      },
      onError: (error) => {
        console.log(error);
      },
    });
  }

  function increase() {
    const newCount = count + 1;
    setCount(newCount);
    set_total_Price(unitPrice * newCount);
    setTotalPriceItems((price) => price + unitPrice);
    updateItem();
  }

  function decrease() {
    if (count == 1) return;
    const newCount = count - 1;
    setCount(newCount);
    set_total_Price(unitPrice * newCount);
    setTotalPriceItems((price) => price - unitPrice);
    updateItem();
  }

  return {
    handleDeleteItem,
    decrease,
    increase,
    openPopup,
    setOpenPopup,
    count,
    total_Price,
    isPending
  };
}
