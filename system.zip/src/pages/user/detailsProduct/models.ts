type Image = {
  id: string;
  url: string;
};

type Category = {
  name: string;
  slug: string;
};

type Addons = {
  id: string;
  menuItemId: string;
  name: string;
  price: number;
};

export type Data = {
  id: string;
  images: Image[];
  isAvailable: boolean;
  name: string;
  hasDiscount: boolean;
  price: number;
  rating: number;
  description: string;
  category: Category;
  addons: Addons[];
};
