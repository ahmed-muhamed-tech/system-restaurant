import { create } from "zustand";
import { persist } from "zustand/middleware";

type CartStore = {
  count: number;
  inc: () => void;
  dec: () => void;
};

export const useCartStore = create<CartStore>()(
  persist(
    (set) => ({
      count: 0,

      inc: () =>
        set((state) => ({
          count: state.count + 1,
        })),

      dec: () =>
        set((state) => ({
          count: Math.max(0, state.count - 1),
        })),
    }),
    {
      name: "cart-storage",
    },
  ),
);
