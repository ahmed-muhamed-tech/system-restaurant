import React from 'react'
import useStore from '../features/auth/storeAuth'

export default function Home() {
  const {userInfo} = useStore()
  return (
    <div>welcome {userInfo?.firstName} dfsds</div>
  )
}
