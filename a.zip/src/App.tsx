
import Routes from "./core/Routes";
export default function App() {
  return (
    <div>
      <Routes/>
    </div>
  );
}
