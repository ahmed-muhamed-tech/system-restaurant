import { Link } from "react-router-dom";
import useStore from "../features/auth/storeAuth";

const linksForRole = {
  user: [
    {
      text: "الرئيسيه",
      link: "/",
    },
    {
      text: "الوجبات",
      link: "/foods",
    },
    {
      text: "تتبع الطلب",
      link: "/order",
    },
  ],
  admin: [
    {
      text: "لوحه التحكم",
      link: "/dashboard-admin",
    },
    {
      text: "فريق التوصيل",
      link: "/deleviry-teams",
    },
  ],
  deleviry: [
    {
      text: "لوحه التحكم",
      link: "/dashboard-deleviry",
    },
  ],
};

export default function MainLayout() {
  const {userInfo} = useStore()
  return (
    <div className="grid grid-cols-6 min-h-screen">
      <div className="absolute bottom-0 left-0 w-full right-0 h-auto lg:relative lg:h-full lg:col-span-1 bg-accent">
        <div className="flex justify-center items-center flex-row py-4 px-2 lg:items-start lg:flex-col gap-5">
          {linksForRole["admin"].map((item, index) => (
            <Link key={index} to={item.link}>
              {item.text}
            </Link>
          ))}
        </div>
      </div>
      <div className="col-span-6 lg:col-span-5 bg-amber-200 p-5">welcome {userInfo?.firstName}</div>
    </div>
  );
}
