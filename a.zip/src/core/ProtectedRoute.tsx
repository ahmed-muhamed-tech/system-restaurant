import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

type Props = {
  children: React.ReactNode;
  allowedRoles?: string[];
  userRole?: string;
};

export default function ProtectedRoute({
  children,
  allowedRoles,
  userRole,
}: Props) {
  const navigate = useNavigate();

  useEffect(() => {
    if (!userRole) {
      toast.warning("يجب تسجيل الدخول");
      navigate("/auth/login");
      return;
    }

    if (allowedRoles && !allowedRoles.includes(userRole)) {
      toast.error("غير مسموح لك بالدخول");
      navigate("/");
    }
  }, [userRole, allowedRoles, navigate]);

  if (!userRole) return null;

  if (allowedRoles && !allowedRoles.includes(userRole)) return null;

  return children;
}