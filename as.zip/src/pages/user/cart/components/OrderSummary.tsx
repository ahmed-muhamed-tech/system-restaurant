export default function OrderSummary({cartSubtotal}: {cartSubtotal: number}) {
  return (
    <div className="lg:w-1/3 p-4 rounded-xl mt-12 h-fit bg-white">
      <h3 className="text-xl text-gray-800">ملخص الطلب</h3>

      <div className="mt-4 flex flex-col gap-1 mb-2 pb-3 border-b border-gray-500">
        <div className="flex items-center justify-between text-sm text-gray-600">
          <h4>المجموع الفرعي</h4>
          <h4>364 ج.م</h4>
        </div>
        <div className="flex items-center justify-between text-sm text-gray-600">
          <h4>رسوم التوصيل</h4>
          <h4>63 ج.م</h4>
        </div>
        <div className="flex items-center justify-between text-sm text-gray-600">
          <h4>الخصم</h4>
          <h4>36 ج.م</h4>
        </div>
        <div className="flex items-center justify-between text-sm text-gray-600">
          <h4>الضريبه</h4>
          <h4>68 ج.م</h4>
        </div>
      </div>

      <div className="flex justify-between items-center mb-5 text-2xl">
        <h3>الاجمالي</h3>

        <h3 className="text-primary">{cartSubtotal} ج.م</h3>
      </div>

      <button className="text-white bg-primary text-center w-full mt-2 rounded-2xl py-3 text-xl hover:font-bold transition-all duration-300">
        اتمام الطلب
      </button>
    </div>
  );
}
